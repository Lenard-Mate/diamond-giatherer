# diamond-gatherer

# Curs 1
- Creare fisier html
- Creare fisier css
- Creare fisier js
- Link intre html, css, js
- How to use git.

# Curs 2
- Function, arrow functions.
- Callbacks
- Context (what is this, how this works)
- Structuri repetitive (while, do while, for, foreach)
- OOP in JS (constructor, classes, methods, properties. JS Module.
- Draw a shape in canvas.
- Draw an image in canvas.
- JS events keydown, click, etc.

# Curs 3
- Client & Server
- Node JS, NPM
- Websockets
- Create

# Curs 4
+ Player Backend Movement
+ Game List
+ Join Game
+ Remove game from list when there are two players
1/2 - Game Over on Disconnect
